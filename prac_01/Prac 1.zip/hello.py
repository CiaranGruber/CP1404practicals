

print('Hello world')